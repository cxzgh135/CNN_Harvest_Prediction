var express = require('express');
var app = express();
var server = require('http').createServer(app);
// http server를 socket.io server로 upgrade한다
var io = require('socket.io')(server);
var ps = require('python-shell');
var fs = require('fs');
var sleep = require('system-sleep');
var request = require('request');
var imageArr = ['apple1.jpg', 'apple2.jpg','apple3.jpg','apple4.jpg','apple5.jpg'];
var resultArr = [] ;
var objects;
var yields;
var harvest;
var abb=1;
var imagename;
app.listen(4000, function(){
  console.log('HTTP Server listening on port 4000');
});





// 클라이언트가 연결되었을때의 확인 메시지
server.listen(3000, function() {
  console.log('Socket IO server listening on port 3000');
});


var a, b, c, d,e,f,g;
  var pycount=1;
// 클라이언트가 연결되고 난 뒤 Order 을 받았을때의 행동 정리
var count = 0 ;
// 연결이 성립하였을때 작동
io.on('connection', function(socket) {
  count++;
  console.log('Connected Client! sum :', count);
  // 파이썬 파일을 실행시키는 함수 ( cnn 모듈을 실행하는데 사용한다. )


  var arrcount = 0;
  socket.on('predict', function (data) {
    imagename = data.data;
    console.log(' ');
    console.log('Requested Predict Image name: ',imagename);
    // PYTHON 파일 실행 ( CNN 작동을 위한 사전 변수정의 및 설정 )

    var options = {
      mode: 'text',
      pythonPath:'',
      pythonOptions: ['-u'],
      scriptPath: '',
      args: [a,b,c,imagename,pycount],
    };
    ps.PythonShell.run('modelC.py',options, function (err,results) {
      if (err) throw err;
      console.log('results: %j', results);
      var data1 = results[0];
      var words = data1.split(' ');
      yields  = words[1].substring(0,words[1].length-1);
      harvest = words[2];
      objects = words[3];
      var stringsplitO =objects.substring(1,6);

      var stringsplitH =harvest.substring(1,5);
      var intresultharvest = stringsplitH.substring(0,2) +' 월 ' +stringsplitH.substring(2,4)+ ' 일';
      var stringsplit = yields.substring(1,3);
      var intresultyield = stringsplit + ' 개';
      resultArr[arrcount] = {'yield':intresultyield, 'harvest':intresultharvest, 'Object':stringsplitO};
      socket.emit('predicted',{yield:intresultyield, harvest:intresultharvest, Object:stringsplitO});
      arrcount++;
      pycount++;
    });
  });
// 연결이 끊겼을 시 작동하는 함수
  socket.on('disconnect', function () {
    console.log("");
    console.log(resultArr);
    count --;
    console.log('user disconnected! sum :', count);
  });
});
var imgcount =0;

// 웹에서 보이기 위한 HTTP 라우팅
app.get('/',function(request,response){
 fs.createReadStream("./main.html").pipe(response);
});

app.get('/data', function(req, res){
  var httpresult = {};
  httpresult["harvest"] =resultArr[imgcount].harvest;
  httpresult["yield"] = resultArr[imgcount].yield;
  httpresult["object"] = resultArr[imgcount].Object;
  httpresult["Path"] = imageArr[imgcount];
  console.log("Send JSON to HTML Page");
  res.json(httpresult);
  imgcount++;
});


app.get('/imgs0', function(req, res){
    fs.readFile('predicted/apple1.jpg', function(error, data){
      res.writeHead(200, {'Content-Type':'text.html'});
      res.end(data);
    });
});
app.get('/imgs1', function(req, res){
    fs.readFile('predicted/apple2.jpg', function(error, data){
      res.writeHead(200, {'Content-Type':'text.html'});
      res.end(data);

    });
});
app.get('/imgs2', function(req, res){
    fs.readFile('predicted/apple3.jpg', function(error, data){
      res.writeHead(200, {'Content-Type':'text.html'});
      res.end(data);

    });
});
app.get('/imgs3', function(req, res){
    fs.readFile('predicted/apple4.jpg', function(error, data){
      res.writeHead(200, {'Content-Type':'text.html'});
      res.end(data);

    });
});
app.get('/imgs4', function(req, res){
    fs.readFile('predicted/apple5.jpg', function(error, data){
      res.writeHead(200, {'Content-Type':'text.html'});
      res.end(data);

    });
});

app.get('/imgsbasic', function(req, res){
    fs.readFile('ratio2.png', function(error, data){
      res.writeHead(200, {'Content-Type':'text.html'});
      res.end(data);

    });
});
