
var path = 'http://localhost:3000';
var imageArr = ['apple1.jpg', 'apple2.jpg','apple3.jpg','apple4.jpg','apple5.jpg'];
var socket = require('socket.io-client')(path);
var ps = require('python-shell');
var sleep = require('system-sleep');
var readline = require('readline');
var fs = require('fs');

var a , b, c, d,e,f,g;
var flag = false;
var options = {
  mode: 'text',
  pythonPath:'',
  pythonOptions: ['-u'],
  scriptPath: '',
  args: [a,b,c,d],
};

var rl = readline.createInterface({
  input:process.stdin,
  output:process.stdout
});


var flag = false;
var imagecount = 0;
var imagepath;
var args = process.argv;
var resultArr = [] ;
var resultcount = 0;
  var resultyield;
  var resultharvest;
  var resultObjects;
socket.on('predicted', function (data) {
  resultyield = data.yield;
  resultharvest = data.harvest;
  resultObjects = data.Object;
  resultArr[resultcount] = {'yield':resultyield,'harvest':resultharvest,'object':resultObjects};
  console.log("");
  console.log("┌────────────────────────────────────────────────┐");
  console.log("│ 【Predict Result】");
  console.log("│ 파일명 ", imageArr[resultcount]);
  console.log("│ 품명 : ",resultArr[resultcount].object);
  console.log("│ 예상 수확시기 : ", resultArr[resultcount].harvest);
  console.log("│ 예상 수확량 : ",resultArr[resultcount].yield);
  console.log("└────────────────────────────────────────────────┘");
    resultcount++;
  });

function predict(){
    imagepath = imageArr[imagecount];

    console.log("");
    socket.emit('predict',{data:imagepath});
    console.log('Predict image by Server.js');
    console.log("Predict Start ...");
    sleep(10000);
};


console.log('Connected TO SERVER');
var data = 0;
for(var i =0; i<imageArr.length; i++){
  predict();
  imagecount = imagecount + 1;
}
console.log("");
console.log("┌────────────────────────────────────────────────┐");
console.log("│finish Predict ! || Check http://localhost:4000 │");
console.log("└────────────────────────────────────────────────┘");
socket.disconnect();
