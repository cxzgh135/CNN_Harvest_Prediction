import cv2
import numpy as np
import matplotlib.pyplot as plt
import sys
import os

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
classes = ["person", "bicycle", "car", "motorcycle",
            "airplane", "bus", "train", "truck", "boat", "traffic light", "fire hydrant",
            "stop sign", "parking meter", "bench", "bird", "cat", "dog", "horse",
            "sheep", "cow", "elephant", "bear", "zebra", "giraffe", "backpack",
            "umbrella", "handbag", "tie", "suitcase", "frisbee", "skis",
            "snowboard", "sports ball", "kite", "baseball bat", "baseball glove", "skateboard",
            "surfboard", "tennis racket", "bottle", "wine glass", "cup", "fork", "knife",
            "spoon", "bowl", "banana", "apple", "sandwich", "apple", "broccoli", "carrot", "hot dog",
            "pizza", "donut", "cake", "chair", "couch", "potted plant", "bed", "dining table",
            "toilet", "tv", "laptop", "mouse", "remote", "keyboard",
            "cell phone", "microwave", "oven", "toaster", "sink", "refrigerator",
            "book", "clock", "vase", "scissors", "teddy bear", "hair drier", "toothbrush" ]

net = cv2.dnn.readNet("yolov3.weights", "yolov3.cfg")

layer_names = net.getLayerNames()
output_layers = [layer_names[i[0] - 1] for i in net.getUnconnectedOutLayers()]
colors = np.random.uniform(0, 255, size=(len(classes), 3))
path = sys.argv[4];
img = cv2.imread(path);
height, width, channels = img.shape


blob = cv2.dnn.blobFromImage(img, 0.00392, (128, 128), (0, 0, 0), True, crop=False)
net.setInput(blob)
outs = net.forward(output_layers)

class_ids = []
confidences = []
boxes = []

for out in outs:
    for detection in out:
        scores = detection[5:]
        class_id = np.argmax(scores)
        confidence = scores[class_id]
        if confidence > 0.1:
            # Object detected
            center_x = int(detection[0] * width)
            center_y = int(detection[1] * height)
            w = int(detection[2] * width)
            h = int(detection[3] * height)

            # Rectangle coordinates
            x = int(center_x - w / 2)
            y = int(center_y - h / 2)

            boxes.append([x, y, w, h])
            confidences.append(float(confidence))
            class_ids.append(class_id)
pathcount = sys.argv[5];
indexes = cv2.dnn.NMSBoxes(boxes, confidences, 0.1, 0.4)
returnPath ='predicted/apple'+ str(pathcount)+'.jpg'
count =0
name = ''
font = cv2.FONT_HERSHEY_PLAIN
for i in range(len(boxes)):
    if i in indexes:
        x, y, w, h = boxes[i]
        label = str(classes[class_ids[i]])
        color = colors[i]
        cv2.rectangle(img, (x, y), (x + w, y + h), color, 2)
        cv2.putText(img, label, (x, y - 10), font, 1, color, 2)
        if label =='apple' :
            count = count+1;
            name = 'apple';
if count <10:
    count = '0' + str(count)
else:
    count =str(count)



        #print(label,confidences[i],x,y,w,h)
        #print(count)
status = cv2.imwrite(returnPath,img);




from keras.models import load_model
from keras.preprocessing import image
from keras.preprocessing.image import ImageDataGenerator
import cv2
from PIL import Image

categories =["1028","1026","1023","1020","1018"]
#categories =["1018","1020","1023","1026","1028"]
model = load_model('testcnn1.h5')
test_image = path
img = Image.open(test_image)
img = img.convert("RGB")
img = img.resize((64,64))
data = np.asarray(img)
X = np.array(data)
X = X.astype("float") / 256
X = X.reshape(-1, 64, 64,3)
# 예측
pred = model.predict(X)
result = [np.argmax(value) for value in pred]   # 예측 값중 가장 높은 클래스 반환
predictions = categories[result[0]]





sys.argv[1] = count;
sys.argv[2] = predictions
sys.argv[3] = name;
sys.argv[4] = sys.argv[4];
sys.argv[5] = pathcount;
print(sys.argv)
